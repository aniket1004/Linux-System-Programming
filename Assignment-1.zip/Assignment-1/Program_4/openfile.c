#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
	int fd = 0;
	if (argc != 2)
	{
		printf ("Invalid number of arguments\n");
		printf ("Use --help \n");
		return -1;
	}
	if (strcmp(argv[1],"--help") == 0)
	{
		printf ("Usage : executable_file filename\n");
		printf ("Example : %s demo.txt\n",argv[0]);
		return 0;
	}
	fd = open(argv[1],O_RDONLY);
	if (fd == -1)
	{
		printf("%s\n",strerror(errno));
		return -1;
	}
	printf ("File %s open successfully\n",argv[1]);
	if (close(fd) == -1)
	{
		printf ("%s\n",strerror(errno));
		return -1;
	}

	return 0;
}
