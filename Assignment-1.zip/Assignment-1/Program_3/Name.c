#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	if (argc != 2)
	{
		printf ("Invalid number of arguments \n");
		printf ("Use --help\n");
		return -1;
	}
	else 
	{
		if(strcmp(argv[1],"--help")==0)
		{
			printf ("Usage : executable_file name\n");
			printf ("Example : %s aniket\n",argv[0]);
			return 0;
		}
		else
		{
			printf ("Your name is %s\n",argv[1]);
			return 0;
		}
	}
	return 0;
}
