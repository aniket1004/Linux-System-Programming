#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>

int main(int argc, char *argv[])
{
	int fd = 0, cnt= 0;
	char ch = '\0';
	if (argc != 2)
	{
		printf ("Invalid number of arguments\n");
		printf ("Use --help\n");
		return -1;
	}
	else
	{
		if (strcmp(argv[1],"--help") == 0)
		{
			printf ("Usage : executable_file filename\n");
			printf ("Example : %s demo.txt\n",argv[0]);
			return -1;
		}

		fd = open(argv[1],O_RDONLY);	
		if (fd == -1)
		{
			printf ("%s\n",strerror(errno));
			return -1;
		}
		while ((cnt < 5) && (read(fd,&ch,sizeof(ch)) > 0))
		{
			printf("%c",ch);
			cnt++;
		}
		printf ("\n");
		if (close(fd) == -1)
		{
			printf ("%s\n",strerror(errno));
			return -1;
		}
	}
	return 0;
}
