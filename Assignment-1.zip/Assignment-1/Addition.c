#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	int iNo1 = 0 , iNo2 = 0 , iAns = 0;
	printf ("%d",argc);
		scanf ("%d %d",&iNo1,&iNo2);
		printf ("Addition is %d\n",iNo1+iNo2); 
	
	return 0;
}
