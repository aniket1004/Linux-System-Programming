#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>

int main(int argc, char *argv[])
{
	int fd = 0, cnt= 0;
	char ch = '\0';
	if (argc != 3 && argc != 2)
	{
		printf ("Invalid number of arguments\n");
		printf ("Use --help\n");
		return -1;
	}
	else if (argc == 2)
	{
		if (strcmp(argv[1],"--help") == 0)
		{
			printf ("Usage : executable_file filename data\n");
			printf ("Example : %s demo.txt abc\n",argv[0]);
			return -1;
		}
		else
		{
			printf ("Invalid number of arguments\n");
                	printf ("Use --help\n");
                	return -1;
		}
	}
	else
	{
		fd = open(argv[1],O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);	
		if (fd == -1)
		{
			printf ("%s\n",strerror(errno));
			return -1;
		}
		lseek(fd,0,SEEK_END);
		if ( write(fd,argv[2],strlen(argv[2])) == -1)
		{
			printf ("%s\n",strerror(errno));
			return -1;
		}
		printf ("Data written successfully\n");
		if (close(fd) == -1)
		{
			printf ("%s\n",strerror(errno));
			return -1;
		}
	}
	return 0;
}
