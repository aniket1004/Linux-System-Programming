#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <stdio.h>

#ifndef BUFFER_SIZE
#define BUFFER_SIZE 1024
#endif

int main(int argc,char *argv[])
{
	int inputFd = 0, outputFd = 0;
	char buf[BUFFER_SIZE] = {'\0'};
	ssize_t numRead;
	if (argc != 3)
	{
		printf ("Invalid numbers of arguments\n");
		printf ("Usage : executable_file source_file dest_file\n");
		printf ("Example : %s demo.txt abc.txt\n",argv[0]);
		return -1;
	}
	inputFd = open(argv[1],O_RDONLY);
	outputFd = open(argv[2],O_WRONLY);
	if (inputFd == -1)
	{
		printf ("Unable to open file %s\n",argv[1]);
		return -1;
	}
	if (outputFd == -1)
	{
		if (errno == ENOENT)
		{
			creat(argv[2],0664);
			outputFd = open(argv[2],O_WRONLY);
		        if (outputFd == -1)
			{
				printf ("Unable to open file %s\n",argv[2]);	
				return -1;
			}
		}
		else
		{
			printf ("Unable to open file %s\n",argv[2]);
			return -1;
		}
	}
	while ((numRead = read(inputFd,buf,BUFFER_SIZE)) > 0)
	{
		if (write(outputFd,buf,numRead) != numRead)
		{
			printf ("Data not fully write\n");
			return -1;
		}
	}
	printf ("File %s copy into %s successfully\n",argv[1],argv[2]);	
	return 0;
}
