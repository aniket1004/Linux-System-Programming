Title 		: 	Copy file into another file.

Description     :	Accept two file and copy first file data into another file.

Build           :	(without makefile) gcc -o copyfile copyfile.c  
			(with makefile) make build
			
Usage		: 	(without makefile) ./copyfile input_file output_file 
				(with makefile) make ARGS="file_name file_name" run

