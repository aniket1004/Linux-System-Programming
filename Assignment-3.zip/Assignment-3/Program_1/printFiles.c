#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>

int main(int argc,char *argv[])
{
	DIR *dir = NULL;
	struct dirent *d = NULL;
	struct stat s;
	int ret = 0;
	
	if (argc != 2)
	{
		printf ("Invalid numbers of arguments\n");
		printf ("Usage : executable_file directory_path\n");
		printf ("Example : %s Program_1\n",argv[0]);
		return -1;
	}
	else
	{
		ret = stat(argv[1],&s);
		if (ret == -1)
		{
			printf ("Directory not exist\n");
			printf ("Please check path again\n");
			return -1;
		}
		if ((s.st_mode & S_IFMT) == S_IFDIR)
		{

			dir = opendir(argv[1]);
			if (dir == NULL)
			{
				printf ("%s\n",strerror(errno));
				printf ("Check directory path\n");
				return -1;
			}
			while (1)
			{
				d = readdir(dir);
				if (d == NULL)
					break;
				if (strcmp(d->d_name,".")!=0 && strcmp(d->d_name,"..")!=0)
					printf ("%s\n",d->d_name);
			}
			if (closedir(dir) == -1)
			{
				printf ("Unable to close directory");
				return -1;
			}
		}

		else
		{
			printf ("It is not directory\n");
			printf ("Please check path again\n");
		}
	}
	return 0;
}
