Title 		: 	Display files and their type of given directory.

Build           :	(without makefile) gcc -o printFiles printFiles.c  
			(with makefile) make build
			
Usage		: 	(without makefile) ./printFiles directory_name 
				(with makefile) make ARGS="directory_name" run

