Title 		: 	 file present or not in given directory.

Description     :      Accept directory and filename from user. check whether file is present in directory or not.

Build           :	(without makefile) gcc -o filepresent filepresent.c  
			(with makefile) make build
			
Usage		: 	(without makefile) ./filepresent directory_name file_name 
				(with makefile) make ARGS="directory_name file_name" run

