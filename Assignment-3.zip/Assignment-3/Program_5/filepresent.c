#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <dirent.h>

int main(int argc, char *argv[])
{
	struct dirent *d = NULL;
	DIR *dir = NULL;
	int flag = 0;
	if (argc != 3)
	{
		printf ("Invalid numbers of arguments\n");
		printf ("Usage : executable_file directory_name file_name\n");
		printf ("Example : %s . demo.txt\n",argv[0]);
		return -1;
	}
	dir = opendir(argv[1]);
	if (dir == NULL)
	{
		printf ("Invalid directory name .Please check directory name again\n");
		return -1;
	}
	while((d = readdir(dir)) != NULL)
	{
		if (strcmp(d->d_name,argv[2]) == 0)
		{
			flag = 1;
			printf ("File %s is present in given %s directory\n",argv[2],argv[1]);
			break;
		} 
	}
	if (flag == 0)
	{
		printf ("File %s is not present in given %s directory\n",argv[2],argv[1]);
	}
	return 0;
}
