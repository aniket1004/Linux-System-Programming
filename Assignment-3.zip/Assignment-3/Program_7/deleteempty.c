#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>

int main(int argc, char *argv[])
{
	struct stat s;
	struct dirent *d = NULL;
	DIR *dir = NULL;
	
	if (argc != 2)
	{
		printf ("Invalid numbers of arguments\n");
		printf ("Usage : executable_file directory_name\n");
		printf ("Example : %s .\n",argv[0]);
		return -1;
	}
	dir = opendir(argv[1]);
	if (dir == NULL)
	{
		printf ("Invalid directory name\n");
		return -1;
	}
	while ((d = readdir(dir)) != NULL)
	{
		
		stat(d->d_name,&s);
	
		if (((int)s.st_size) == 0)
		{
			printf ("%s\n",d->d_name);
			remove(d->d_name);
		}
		
	}
	return 0;
}
