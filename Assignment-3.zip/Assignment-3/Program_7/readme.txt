Title 		: 	 Delete all empty files from given directory.

Description     :      Accept directory name and delete all empty files from it.

Build           :	(without makefile) gcc -o deleteempty deleteempty.c  
			(with makefile) make build
			
Usage		: 	(without makefile) ./deleteempty directory_name 
				(with makefile) make ARGS="directory_name" run

