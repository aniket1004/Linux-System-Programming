Title 		: 	Display largest file from given directory.

Build           :	(without makefile) gcc -o largeFile largeFile.c  
			(with makefile) make build
			
Usage		: 	(without makefile) ./largeFile directory_name 
				(with makefile) make ARGS="directory_name" run

