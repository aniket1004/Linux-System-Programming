#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>

int main(int argc,char * argv[])
{
	struct stat s;
	struct stat temp;
	struct dirent *d = NULL;
	DIR *dir = NULL;
	int ret = 0;
	int maxFile = 0;
	char *filename = NULL;
	if (argc != 2)
	{
		printf ("Invalid number of arguments \n");
		printf ("Usage : executable_file directory_path\n");
		printf ("example : %s ../abc\n",argv[0]);
	}
	dir = opendir(argv[1]);
	if (dir == NULL)
	{
		printf ("Invalid directory. Please check directory path\n");
		return -1;
	}
	while(1)
	{
		d = readdir(dir);
		if (d == NULL)
			break;
		if ((strcmp(d->d_name,".") != 0) && (strcmp(d->d_name,"..") != 0))
		{
			if (stat(d->d_name,&s) != -1)
			{
				if (maxFile <= ((int)s.st_size))
				{
					temp = s;
					filename = d->d_name;
					maxFile = (int)s.st_size;
				}
			}
		}
	}
		printf ("%s is maximum size file of size %d bytes\n",filename,(int)temp.st_size);
	return 0;
}
