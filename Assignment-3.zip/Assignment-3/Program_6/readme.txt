Title 		: 	 Move all files from one directory to another.

Description     :      Accept two directory names and move all files one directory to another.

Build           :	(without makefile) gcc -o copydirectory copydirectory.c  
			(with makefile) make build
			
Usage		: 	(without makefile) ./copydirectory directory_name directory_name 
				(with makefile) make ARGS="directory_name directory_name" run

