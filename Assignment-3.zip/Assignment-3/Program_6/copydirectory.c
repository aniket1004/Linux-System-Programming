#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <dirent.h>

int main(int argc, char *argv[])
{
	unsigned char buf[4096];
	int dir1 = 0,dir2 = 0;
	int flag = 0;
	ssize_t numRead;
	if (argc != 3)
	{
		printf ("Invalid numbers of arguments\n");
		printf ("Usage : executable_file directory_name file_name\n");
		printf ("Example : %s . demo.txt\n",argv[0]);
		return -1;
	}
	if (rename(argv[1],argv[2]) == -1)
	{
		printf ("%s\n",strerror(errno));
		printf ("Move unsuccessful\n");
		return -1;
	}
	printf ("Move all files from %s to %s sucessful\n",argv[1],argv[2]);
	return 0;
}
