Title 		: 	Read data from given file.

Description 	:	Display given bytes of data from given file.

Build           :	(without makefile) gcc -o readfile readfile.c  
			(with makefile) make build
			
Usage		: 	(without makefile) ./readfile file_name no_of_bytes 
				(with makefile) make ARGS="file_name no_of_bytes" run
			


