Title 		: 	Open the file.

Description 	:	Open the given file in any mode .

Build           :	(without makefile) gcc -o openfile openfile.c  
			(with makefile) make build
			
Usage		: 	(without makefile) ./openfile file_name
			(with makefile) make ARGS="file_name" run

