#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

int main (int argc, char *argv[])
{
	int fd = 0;
	
	if (argc == 2)
	{
		fd = open(argv[1],O_RDONLY);
		if (fd == -1)
		{
			printf ("%s\n",strerror(errno));
			return -1;
		}
		printf ("File %s open successfully at descriptor %d\n",argv[1],fd);
		if (close(fd) == -1)
		{
			printf ("%s\n",strerror(errno));
			return -1;
		}
		
	}
	else
	{
		printf ("Invalid numbers of argument.\n");
		printf ("Usage : %s filename\n",argv[0]);
		printf ("Example : %s Demo.txt\n",argv[0]);

	}	
	return 0;
}
