#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include <string.h>
#include <errno.h>

int main(int argc, char *argv[])
{
    struct stat st;
    if (argc == 2)
    {
        if (stat(argv[1],&st) != -1)
        {
            printf ("Filetype :");
            switch(st.st_mode & S_IFMT)
            {
                case S_IFREG :
                                printf ("Regular file\n");
                                break;
                case S_IFDIR :
                                printf ("Directory file\n");
                                break;
                
            }
            printf ("Inode : %d\n",(int)st.st_ino);
            printf ("Device ID: %d\n",(int)st.st_dev);
            printf ("Number of (hard) links: %d\n",(int)st.st_nlink);
            printf ("Mode :%lo\n",(unsigned long)st.st_mode);
            printf ("Ownership : UID = %ld  GID = %ld\n",(long) st.st_uid,(long) st.st_gid);
            printf ("File size : %ld\n",st.st_size);
            printf ("Optimal I/O block size : %ld\n",st.st_blksize);
            printf ("512B blocks allocated: %ld\n",st.st_blocks);
            printf ("Last file access: %s",ctime(&st.st_atime));
            printf ("Last file modified: %s",ctime(&st.st_mtime));
            printf ("Last status change: %s\n",ctime(&st.st_ctime));

        }
        else
        {
            printf ("%s\n",strerror(errno));
        }
    }
    else
    {

    }
    return 0;
}
