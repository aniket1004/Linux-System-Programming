Title 		: 	Information about the file.

Description 	:	Display information of given file( inode,file size, permission,type,etc...).

Build           :	(without makefile) gcc -o filestat filestat.c  
			(with makefile) make build
			
Usage		: 	(without makefile) ./filestat file_name 
				(with makefile) make ARGS="file_name" run
			


