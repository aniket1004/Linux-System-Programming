#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#define BUFFER_SIZE 1024

int main(int argc, char *argv[])
{
	int readBytes = 0,fd = 0,cnt = 0;
	char data[BUFFER_SIZE] = {'\0'};
	
	if (argc != 2)
	{
		printf ("Invalid numbers of arguments\n");
		printf ("Usage : executable_file file_name\n");
		printf ("Example : %s abc.txt\n",argv[0]);
		return -1;
	}
	fd = open(argv[1],O_RDONLY);
	if (fd == -1)
	{
		printf ("Unable to open file or file not exist\n");
		return -1;
	}
	while ((readBytes = read(fd,data,BUFFER_SIZE)) > 0)
	{
		if (write(1,data,readBytes) != readBytes)
		{
			printf ("Data was not fully read\n");
			return -1;
		}
	}
	if (close(fd) == -1)
	{
		printf ("Unable to close file\n");
		return -1;
	}
	
	return 0;
}
