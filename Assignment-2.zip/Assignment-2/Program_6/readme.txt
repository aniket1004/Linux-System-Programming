Title 		: 	Read data from given file.

Description 	:	Display whole data from given file.

Build           :	(without makefile) gcc -o readwholefile readwholefile.c  
			(with makefile) make build
			
Usage		: 	(without makefile) ./readwholefile file_name 
				(with makefile) make ARGS="file_name" run
			


