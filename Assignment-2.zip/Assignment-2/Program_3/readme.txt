Title 		: 	Open the file.

Description 	:	Open the given file in given specific mode .

Build           :	(without makefile) gcc -o openfile openfile.c  
			(with makefile) make build
			
Usage		: 	(without makefile) ./openfile file_name mode
				(with makefile) make ARGS="file_name mode" run
				mode : r (for read)
			    	   w (for write)
			       	   rw (for read and write)
			
Output 		: 	File open in given mode successfully or not (if not then why? )

