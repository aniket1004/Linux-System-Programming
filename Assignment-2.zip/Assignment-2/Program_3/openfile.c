#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

int main(int argc, char *argv[])
{
    int fd = 0;
    long mode = 0;

    
    if (argc == 3)
    {
        if (strcmp(argv[2],"rw") == 0)
        {
            mode = O_RDWR;
        }
        else if (argv[2][0] == 'r')
        {
            mode = O_RDONLY;
        } 
        else if (argv[2][0] == 'w')
        {
            mode = O_WRONLY;
        } 
        else
        {
            printf ("Invalid file mode\n");
            printf ("Usage : %s file_name mode\n",argv[0]);
            printf ("Third parameter( mode ): r (for read) , w (for write), rw (for readwrite)\n");
            printf ("Using makefile : make \"ARGS=\"file_name mode\" run\n"); 
            return -1;
        }
        fd = open(argv[1],mode);
        if (fd == -1)
        {
            if (errno == EACCES)
            {
                printf ("Permission Denied :File %s not have permission to open file in %s mode\n",argv[1],argv[2]);
            }
            else
            {
                printf ("%s\n",strerror(errno));
            }
            return 0;
        }
        printf ("File %s open succesfully in %s mode at descriptor %d.\n",argv[1],argv[2],fd);
        if (close(fd) == -1)
        {
            printf ("Unable to close file \n");
            return -1;
        }
    }
    else
    {
        printf ("Invalid numbers of arguments\n");
        printf ("Usage : %s file_name r\n",argv[0]);
        printf ("Third parameter mode : r (for read) , w (for write), rw (for readwrite)\n");
 	printf ("Using makefile : make ARGS=\"file_name mode\" run\n"); 
            
    }

    return 0;
}
