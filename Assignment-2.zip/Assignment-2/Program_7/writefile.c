#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

int main(int argc, char *argv[])
{
	int readBytes = 0,fd = 0,cnt = 0;
	char data = '\0';
	
	if (argc != 3)
	{
		printf ("Invalid numbers of arguments\n");
		printf ("Usage : executable_file file_name data\n");
		printf ("Example : %s abc.txt xyz\n",argv[0]);
		return -1;
	}
	
	fd = open(argv[1],O_WRONLY);
	if (fd == -1)
	{
		if ( errno == ENOENT)
		{
			creat(argv[1],0664);
			fd = open(argv[1],O_WRONLY);
			if (fd == -1)
			{
				printf ("Unable to open file\n");
				return -1;
			}
		}
		else
		{
			printf ("Unable to open file\n");
			return -1;
		}
	}
	if (write(fd,argv[2],strlen(argv[2])) != strlen(argv[2]))
	{
		printf ("Data was not fully write in file\n");
		return 0;
	}
	else
	{
		printf ("Data written successfully in file\n");
	}
	if (close(fd) == -1)
	{
		printf ("Unable to close file\n");
		return -1;
	}
	
	return 0;
}
