Title 		: 	Write data into given file.

Description 	:	Write given string of data into given file.

Build           :	(without makefile) gcc -o writefile writefile.c  
			(with makefile) make build
			
Usage		: 	(without makefile) ./writefile file_name string 
				(with makefile) make ARGS="file_name string" run
			


