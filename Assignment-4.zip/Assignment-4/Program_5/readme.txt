This program which accept file name and position from user and read 20 bytes from that position.
