#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <malloc.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int inputFd = 0;
	int pos = 0;
	int fileSize = 0;
	int cnt = 0;
	char ch = '\0';

	if (argc != 3)
	{
		printf ("Invalid numbers of arguments\n");
		printf ("Usage : make ARGS=\"file_name position\" run\n");
		return -1;
	}
	pos = atoi(argv[2]);
	inputFd = open(argv[1],O_RDONLY);
	if (inputFd == -1)
	{
		printf ("%s\n",strerror(errno));
		return -1;
	}
	fileSize = lseek(inputFd,0,SEEK_END);
	
	printf ("File name :%s\n",argv[1]);
	printf ("File size :%d\n",fileSize);
	
	if (fileSize <= pos)
	{
		printf ("Position is greater than or equal to file size\n");
		close(inputFd);
		return -1;
	}
	lseek(inputFd,pos-1,SEEK_SET);
	while ((cnt < 20) && ((read(inputFd,&ch,1)) > 0))
	{
		printf ("%c",ch);
		cnt++;
	}
	close(inputFd);
	return 0;
}
