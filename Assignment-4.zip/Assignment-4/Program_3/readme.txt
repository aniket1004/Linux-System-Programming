This program accept two file names from user and check whether contents of that two files are equal are not.
