#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#ifndef BUFFER_SIZE
#define BUFFER_SIZE 512
#endif

int main(int argc,char *argv[])
{
	int fd1 = 0, fd2 = 0; 
	int sizef1 = 0,sizef2 = 0;
	char buf1[BUFFER_SIZE] = {'\0'};
	char buf2[BUFFER_SIZE] = {'\0'};
	int flag = 0;
	if (argc != 3)
	{
		printf ("Invalid number of arguments\n");
		printf ("Usage : make ARGS=\"first_file second_file\" run\n");
		return -1;
	}
	fd1 = open(argv[1],O_RDONLY);
	if (fd1 == -1)
	{
		printf ("Unable to open file %s or file not exist\n",argv[1]);
		return -1;
	}
	fd2 = open(argv[2],O_RDONLY);
	if (fd2 == -1)
	{
		printf ("Unable to open file %s or file not exist\n",argv[2]);
		return -1;
	}
	// SEEK_SET   SEEK_CUR    SEEK_END
	sizef1 = lseek(fd1,0,SEEK_END);
	sizef2 = lseek(fd2,0,SEEK_END);
	lseek(fd1,0,SEEK_SET);
	lseek(fd2,0,SEEK_SET);
	
	if (sizef1 == sizef2)
	{
		while ( (read(fd1,buf1,BUFFER_SIZE-1) > 0) && (read(fd2,buf2,BUFFER_SIZE-1) > 0))
		{
			if(strcmp(buf1,buf2) != 0)
			{
				
				flag = 1;
				break;	
			}
			memset(buf1,'\0',strlen(buf1));
			memset(buf2,'\0',strlen(buf2));
		}
		if (flag == 1)
		{
			printf ("Contents in both files not same\n");
		}
		else
		{
			printf ("Contents in both file are same\n");
		}
	}
	else
	{
		printf ("Contents in both files not same\n");
	}
	close(fd1);
	close(fd2);		
	return 0;
}
