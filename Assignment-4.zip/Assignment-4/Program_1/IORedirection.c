/* Write a program which is used to demonstrate concept of I/O redirection. */

#include <stdio.h>

int main()
{
	char buf[1024] = {'\0'};

	// Here we use input redirection ( < )
	scanf ("%s",buf); 			//  < input.txt
	
	// Here we use output redirection ( > )
	printf ("%s",buf);			// > output.txt
	
	return 0;
}
