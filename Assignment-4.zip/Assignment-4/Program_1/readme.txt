Demonstration of file I/O Redirection

This program accept input through file which is given after ( < ) and write output in file also which is given after ( > )
Append the output in file using ( >> ).
