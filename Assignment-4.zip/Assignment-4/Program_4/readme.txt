This program accept directory name from user and copy first 10 bytes from all regular files into newly created file named as demo.
