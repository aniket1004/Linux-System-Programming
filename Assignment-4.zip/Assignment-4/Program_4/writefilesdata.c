#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <malloc.h>
#include <inttypes.h>

#ifndef FILE_NAME_SIZE
#define FILE_NAME_SIZE 256
#endif

int main(int argc, char *argv[])
{
	DIR *dp = NULL;
	struct dirent *dr = NULL;
	struct stat s;
	int inputFd = 0, outputFd = 0;
	ssize_t readBytes = 0;
	char filename[FILE_NAME_SIZE] = {'\0'};
	char *buf = NULL;
	int flag = 0;
	char newline = '\n';
	if (argc != 2)
	{
		printf ("Invalid numbers of arguments\n");
		printf ("Usage : make ARGS=\"directory_name\" run\n");
		return -1;
	}
	dp = opendir(argv[1]);
	if (dp == NULL)
	{
		printf ("Unable to open directory or not exist\n");
		return -1;
	}
	outputFd = open("demo.txt",O_WRONLY | O_CREAT | O_APPEND,0774);
	if (outputFd == -1)
	{
		printf ("Unable to open or create file demo.txt\n");
		return -1;
	}
	while((dr = readdir(dp)) != NULL)
	{
		sprintf (filename,"%s/%s",argv[1],dr->d_name);

		if (stat(filename,&s) == -1)
		{
			printf ("%s\n",strerror(errno));
			flag = 1;
			closedir(dp);
			printf ("Unable to find information of file %s\n",dr->d_name);
			break;
		}
		if ( S_ISREG(s.st_mode))
		{
			inputFd = open(filename,O_RDONLY);
			if (s.st_size < 10)
			{
				buf = (char *)malloc(s.st_size+1);
				readBytes = read(inputFd,buf,s.st_size);
			}
			else
			{
				buf = (char *)malloc(11);
				readBytes = read(inputFd,buf,10);
			}
			
			write(outputFd,dr->d_name,strlen(dr->d_name));
			write(outputFd,&newline,1);
			write(outputFd,buf,readBytes);
			write(outputFd,&newline,1);
			close(inputFd);
			memset(filename,'\0',FILE_NAME_SIZE);
		}
		buf = NULL;

	}
	if (flag != 1)
	{
		printf ("Data written in file demo.txt sucessfully\n");

	}
	else
	{
	}
	return 0;
}
