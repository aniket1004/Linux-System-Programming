This program accept directory name from user and create new directory of that name.
