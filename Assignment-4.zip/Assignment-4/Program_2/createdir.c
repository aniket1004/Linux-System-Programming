#include <stdio.h>
#include <sys/stat.h>

int main(int argc, char *argv[])
{
	int dp = 0;
	if (argc != 2)
	{
		printf ("Invalid numbers of arguments\n");
		printf ("Usage: executable_file directory_name\n");
		printf ("Example : %s demo\n",argv[1]);
		return -1;
	}
	
	dp = mkdir(argv[1],0774);
	if (dp == -1)
	{
		printf ("Unable to create directory or directory already exist\n");
		return -1;
	}
	printf ("Directory create sucessfully\n");
	return 0;
}
